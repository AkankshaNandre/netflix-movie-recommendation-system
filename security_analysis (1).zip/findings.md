# Findings

## Summary

Authentication logs show repeated failed login attempts.

## Indicators

- IP `192.168.1.10` generated the highest number of failures
- `admin`, `root`, and `guest` were targeted
- Multiple attempts occurred within a short time

## Interpretation

This behavior may indicate a brute-force attack attempt.

## Suggested Mitigation

- Use SSH keys instead of passwords
- Enable rate limiting
- Disable unused accounts
- Monitor suspicious IP activity