# Security Log Analysis

A beginner cybersecurity project that analyzes authentication logs to detect suspicious login attempts.

## Objective

This project identifies:

- repeated failed login attempts
- suspicious IP addresses
- targeted usernames

## Tools Used

- Python
- Regex
- Jupyter Notebook

## Project Files

- security_analysis.ipynb → main analysis notebook
- sample.log → sample authentication logs
- findings.md → investigation report

## Example Output

The script shows:

- top failed IP addresses
- targeted usernames
- suspicious login behavior

## Security Relevance

Useful for:

- SOC analyst learning
- security monitoring
- incident investigation
- beginner cybersecurity portfolio projects